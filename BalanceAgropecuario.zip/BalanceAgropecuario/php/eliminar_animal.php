<?php
session_start();
require_once "conexion.php";
header("Content-Type: application/json; charset=UTF-8");

if (!isset($_SESSION["id_usuario"])) {
    echo json_encode(["status" => "error", "message" => "No hay una sesión iniciada."]);
    exit;
}

$id_usuario = $_SESSION["id_usuario"];

// Detecta tanto petición por POST (JSON) como por GET
$inputJSON = json_decode(file_get_contents("php://input"), true);
$id_animal = $inputJSON["animal_id"] ?? $inputJSON["id_animal"] ?? $inputJSON["AnimalId"] ?? $_GET["id_animal"] ?? $_GET["AnimalId"] ?? $_GET["id"] ?? "";

if ($id_animal === "") {
    echo json_encode(["status" => "error", "message" => "ID de animal no proporcionado."]);
    exit;
}

try {
    $sql = "DELETE FROM Animal WHERE AnimalId = ? AND UsuarioId = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->execute([$id_animal, $id_usuario]);

    if ($stmt->rowCount() > 0) {
        echo json_encode(["status" => "success", "message" => "Animal eliminado correctamente."]);
    } else {
        echo json_encode(["status" => "error", "message" => "No se encontró el registro o no tienes permisos."]);
    }

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Error al eliminar el animal: " . $e->getMessage()]);
}
?>