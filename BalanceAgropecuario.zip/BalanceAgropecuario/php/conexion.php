<?php

$host = "localhost";
$usuario = "root";
$password = "";
$base_datos = "balance_agropecuario";

try {

    $conexion = new PDO(
        "mysql:host=$host;dbname=$base_datos;charset=utf8mb4",
        $usuario,
        $password
    );

    $conexion->setAttribute(
        PDO::ATTR_ERRMODE,
        PDO::ERRMODE_EXCEPTION
    );



} catch (PDOException $e) {

    echo "Error de conexión: " . $e->getMessage();

}

?>