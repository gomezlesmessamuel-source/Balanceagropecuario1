<?php
session_start();
require_once "conexion.php";

if (!isset($_SESSION["id_usuario"])) {
    echo "No hay una sesión iniciada.";
    exit;
}

$id_usuario = $_SESSION["id_usuario"];
$datos = json_decode(file_get_contents("php://input"), true);

$nombre = trim($datos["nombre"] ?? "");
$tipoNombre = ucfirst(strtolower(trim($datos["tipo"] ?? "General")));
$raza = ucfirst(strtolower(trim($datos["raza"] ?? "General")));
$sexo = trim($datos["sexo"] ?? "");
$edad = !empty($datos["edad"]) ? $datos["edad"] : null;
$peso = !empty($datos["peso"]) ? floatval($datos["peso"]) : null;
$alimento_diario = trim($datos["alimento_diario"] ?? "");

// Nuevos campos provenientes del frontend (Select dinámico y calculadora)
$medicamento_id = !empty($datos["medicamento_id"]) ? intval($datos["medicamento_id"]) : null;
$medicamento_nombre = trim($datos["medicamento_nombre"] ?? "");
$dosis = !empty($datos["dosis"]) ? floatval($datos["dosis"]) : null;

$diagnostico = trim($datos["diagnostico"] ?? "");
$observaciones = trim($datos["observaciones"] ?? "");
$proxima_dosis = !empty($datos["proxima_dosis"]) ? $datos["proxima_dosis"] : null;
$fecha_revision = trim($datos["fecha_revision"] ?? date("Y-m-d"));
$hoy = date("Y-m-d");
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $fecha_revision) || $fecha_revision < $hoy) { echo "La fecha de ingreso/revisión no puede ser anterior a hoy."; exit; }
if ($proxima_dosis !== null && $proxima_dosis < $hoy) { echo "La próxima dosis no puede tener una fecha pasada."; exit; }

if ($nombre === "" || $tipoNombre === "" || $peso === null) {
    echo "Por favor complete los campos obligatorios.";
    exit;
}

try {
    $conexion->beginTransaction();

    // 1. Evitar duplicación de Tipo + Raza
    $sqlTipo = "SELECT TipoAnimalId FROM TipoAnimal WHERE LOWER(Nombre) = LOWER(?) AND LOWER(Raza) = LOWER(?)";
    $stmtTipo = $conexion->prepare($sqlTipo);
    $stmtTipo->execute([$tipoNombre, $raza]);
    $tipoExistente = $stmtTipo->fetch(PDO::FETCH_ASSOC);

    if ($tipoExistente) {
        $tipoAnimalId = $tipoExistente["TipoAnimalId"];
    } else {
        $stmtInsTipo = $conexion->prepare("INSERT INTO TipoAnimal (Nombre, Raza) VALUES (?, ?)");
        $stmtInsTipo->execute([$tipoNombre, $raza]);
        $tipoAnimalId = $conexion->lastInsertId();
    }

    // 2. Alimento
    $alimentoId = null;
    if ($alimento_diario !== "") {
        $stmtAlim = $conexion->prepare("SELECT AlimentoId FROM Alimento WHERE LOWER(Nombre) = LOWER(?)");
        $stmtAlim->execute([$alimento_diario]);
        $alimExistente = $stmtAlim->fetch(PDO::FETCH_ASSOC);

        if ($alimExistente) {
            $alimentoId = $alimExistente["AlimentoId"];
        } else {
            $stmtInsAlim = $conexion->prepare("INSERT INTO Alimento (Nombre, Tipo) VALUES (?, 'General')");
            $stmtInsAlim->execute([$alimento_diario]);
            $alimentoId = $conexion->lastInsertId();
        }
    }

    // 3. Guardar Animal vinculado al usuario (usando los datos de medicamento elegidos en el select)
    $sqlAnimal = "INSERT INTO Animal (UsuarioId, TipoAnimalId, Nombre, Sexo, Edad, Peso, AlimentoDiario, Medicamentos, AlimentoId, MedicamentoId, Observaciones) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $stmtAnimal = $conexion->prepare($sqlAnimal);
    $stmtAnimal->execute([$id_usuario, $tipoAnimalId, $nombre, $sexo, $edad, $peso, $alimento_diario, $medicamento_nombre, $alimentoId, $medicamento_id, $observaciones]);
    $animalId = $conexion->lastInsertId();

    // 4. Vacunación (Si se seleccionó un medicamento)
    if ($medicamento_id !== null) {
        $stmtVac = $conexion->prepare("INSERT INTO Vacunacion (AnimalId, MedicamentoId, NombreVacuna, FechaAplicacion, ProximaDosis) VALUES (?, ?, ?, ?, ?)");
        $stmtVac->execute([$animalId, $medicamento_id, $medicamento_nombre, $fecha_revision, $proxima_dosis]);
    }

    // 5. Historial Médico (Usando INSERT para preservar el histórico de revisiones)
    $tratamiento = "";
    if ($medicamento_id !== null) {
        $tratamiento = "Medicamento: " . $medicamento_nombre . " | Dosis: " . $dosis;
    }

    $stmtHistorial = $conexion->prepare("INSERT INTO HistorialMedico (AnimalId, Fecha, Diagnostico, Tratamiento, Observaciones) VALUES (?, ?, ?, ?, ?)");
    $stmtHistorial->execute([$animalId, $fecha_revision, $diagnostico, $tratamiento, $observaciones]);
    $historialId = $conexion->lastInsertId();
    
    // Actualizar el último historial del animal
    $conexion->query("UPDATE Animal SET HistorialMedicoId = $historialId WHERE AnimalId = $animalId");

    // 6. Guardar Control de Peso y Producción (reflejando la dosis calculada)
    $conexion->prepare("INSERT INTO ControlPeso (AnimalId, Fecha, Peso) VALUES (?, ?, ?)")->execute([$animalId, $fecha_revision, $peso]);
    
    // Se inserta en Producción con DosisCalculada
    $conexion->prepare("INSERT INTO Produccion (AnimalId, Fecha, MedicamentoId, DosisCalculada, AlimentoId) VALUES (?, ?, ?, ?, ?)")->execute([$animalId, $fecha_revision, $medicamento_id, $dosis, $alimentoId]);

    $conexion->commit();
    echo "OK";
} catch (PDOException $e) {
    $conexion->rollBack();
    echo "Error al guardar: " . $e->getMessage();
}
?>