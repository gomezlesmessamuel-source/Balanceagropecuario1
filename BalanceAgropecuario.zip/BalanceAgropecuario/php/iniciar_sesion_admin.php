<?php
session_start();
require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $usuario = trim($_POST["usuario"] ?? "");
    $password = $_POST["password"] ?? "";

    if ($usuario === "" || $password === "") {
        echo "Por favor complete todos los campos.";
        exit;
    }

    // Buscar en la tabla administradores
    $sql = "SELECT id_administrador, password FROM administradores WHERE usuario = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->execute([$usuario]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    // Validar contraseña
    if ($admin && $password === $admin["password"]) {
        
        // Crear la sesión del administrador
        $_SESSION["id_administrador"] = $admin["id_administrador"];
        
        echo "Inicio de sesión correcto.";
    } else {
        echo "Usuario o contraseña incorrectos.";
    }
}
?>