<?php
session_start();
require_once "conexion.php";

if (!isset($_SESSION["id_usuario"])) {
    echo "No hay una sesión iniciada.";
    exit;
}

$id_usuario = $_SESSION["id_usuario"];
$datos = json_decode(file_get_contents("php://input"), true);

$id_animal = $datos["animal_id"] ?? $datos["id_animal"] ?? $datos["AnimalId"] ?? "";
$nombre = trim($datos["nombre"] ?? "");
$tipoNombre = ucfirst(strtolower(trim($datos["tipo"] ?? "General")));
$raza = ucfirst(strtolower(trim($datos["raza"] ?? "General")));
$sexo = trim($datos["sexo"] ?? "");
$edad = !empty($datos["edad"]) ? $datos["edad"] : null;
$peso = !empty($datos["peso"]) ? $datos["peso"] : null;
$alimento_diario = trim($datos["alimento_diario"] ?? "");
$medicamentos = trim($datos["medicamentos"] ?? "");
$observaciones = trim($datos["observaciones"] ?? "");
$proxima_dosis = !empty($datos["proxima_dosis"]) ? $datos["proxima_dosis"] : null;
$fecha_revision = trim($datos["fecha_revision"] ?? date("Y-m-d"));
$hoy = date("Y-m-d");
if (!preg_match("/^\d{4}-\d{2}-\d{2}$/", $fecha_revision) || $fecha_revision < $hoy) { echo "La fecha de ingreso/revisión no puede ser anterior a hoy."; exit; }
if ($proxima_dosis !== null && $proxima_dosis < $hoy) { echo "La próxima dosis no puede tener una fecha pasada."; exit; }

if ($id_animal === "" || $nombre === "" || $tipoNombre === "") {
    echo "Por favor complete los campos obligatorios.";
    exit;
}

try {
    $conexion->beginTransaction();

    // 1. Obtener o crear TipoAnimal (Nombre + Raza)
    $sqlTipo = "SELECT TipoAnimalId FROM TipoAnimal WHERE LOWER(Nombre) = LOWER(?) AND LOWER(Raza) = LOWER(?)";
    $stmtTipo = $conexion->prepare($sqlTipo);
    $stmtTipo->execute([$tipoNombre, $raza]);
    $tipoExistente = $stmtTipo->fetch(PDO::FETCH_ASSOC);

    if ($tipoExistente) {
        $tipoAnimalId = $tipoExistente["TipoAnimalId"];
    } else {
        $sqlInsTipo = "INSERT INTO TipoAnimal (Nombre, Raza) VALUES (?, ?)";
        $stmtInsTipo = $conexion->prepare($sqlInsTipo);
        $stmtInsTipo->execute([$tipoNombre, $raza]);
        $tipoAnimalId = $conexion->lastInsertId();
    }

    // 2. Actualizar datos en la tabla Animal
    $sql = "UPDATE Animal 
            SET Nombre = ?, TipoAnimalId = ?, Sexo = ?, Edad = ?, Peso = ?, AlimentoDiario = ?, Medicamentos = ?, Observaciones = ? 
            WHERE AnimalId = ? AND UsuarioId = ?";

    $stmt = $conexion->prepare($sql);
    $stmt->execute([
        $nombre,
        $tipoAnimalId,
        $sexo,
        $edad,
        $peso,
        $alimento_diario,
        $medicamentos,
        $observaciones,
        $id_animal,
        $id_usuario
    ]);

    // 3. Actualizar o insertar la próxima dosis en Vacunación si se ingresó
    if (!empty($proxima_dosis)) {
        $stmtVacCheck = $conexion->prepare("SELECT VacunacionId FROM Vacunacion WHERE AnimalId = ? ORDER BY VacunacionId DESC LIMIT 1");
        $stmtVacCheck->execute([$id_animal]);
        $vacExistente = $stmtVacCheck->fetch(PDO::FETCH_ASSOC);

        if ($vacExistente) {
            $stmtVacUpd = $conexion->prepare("UPDATE Vacunacion SET ProximaDosis = ?, NombreVacuna = ?, FechaAplicacion = ? WHERE VacunacionId = ?");
            $stmtVacUpd->execute([$proxima_dosis, $medicamentos, $fecha_revision, $vacExistente['VacunacionId']]);
        } else {
            $stmtVacIns = $conexion->prepare("INSERT INTO Vacunacion (AnimalId, NombreVacuna, FechaAplicacion, ProximaDosis) VALUES (?, ?, ?, ?)");
            $stmtVacIns->execute([$id_animal, $medicamentos ?: 'Revisión', $fecha_revision, $proxima_dosis]);
        }
    }

    $conexion->commit();
    echo "OK";

} catch (PDOException $e) {
    $conexion->rollBack();
    echo "Error al modificar el animal: " . $e->getMessage();
}
?>