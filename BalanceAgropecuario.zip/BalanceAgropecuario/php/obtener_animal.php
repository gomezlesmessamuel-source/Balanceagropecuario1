<?php
session_start();
require_once "conexion.php";
header("Content-Type: application/json; charset=UTF-8");

if (!isset($_SESSION["id_usuario"])) {
    echo json_encode(["status" => "error", "message" => "No hay una sesión iniciada."]);
    exit;
}

$id_usuario = $_SESSION["id_usuario"];
$id_animal = $_GET["id_animal"] ?? $_GET["AnimalId"] ?? $_GET["id"] ?? "";

try {
    if ($id_animal !== "") {
        $sql = "SELECT 
                    a.AnimalId as id_animal,
                    a.AnimalId,
                    a.UsuarioId as id_usuario,
                    a.Nombre as nombre,
                    t.Nombre as tipo,
                    t.Raza as raza,
                    a.Sexo as sexo,
                    a.Edad as edad,
                    a.Peso as peso,
                    a.AlimentoDiario as alimento_diario,
                    a.Medicamentos as medicamentos,
                    a.Observaciones as observaciones,
                    (SELECT MIN(v.ProximaDosis) FROM Vacunacion v WHERE v.AnimalId = a.AnimalId AND v.ProximaDosis >= CURDATE()) as proxima_dosis,
                    (SELECT v.FechaAplicacion FROM Vacunacion v WHERE v.AnimalId = a.AnimalId ORDER BY v.VacunacionId DESC LIMIT 1) as fecha_revision,
                    (SELECT h.Diagnostico FROM HistorialMedico h WHERE h.AnimalId = a.AnimalId ORDER BY h.Fecha DESC LIMIT 1) as diagnostico
                FROM Animal a
                LEFT JOIN TipoAnimal t ON a.TipoAnimalId = t.TipoAnimalId
                WHERE a.AnimalId = ? AND a.UsuarioId = ?";

        $stmt = $conexion->prepare($sql);
        $stmt->execute([$id_animal, $id_usuario]);
        $animal = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$animal) {
            echo json_encode(["status" => "error", "message" => "El animal no existe o no tienes permisos."]);
            exit;
        }
        echo json_encode(["status" => "success", "data" => $animal]);
        exit;
    }

    $sql = "SELECT 
                a.AnimalId as id_animal,
                a.AnimalId,
                a.Nombre as nombre,
                t.Nombre as tipo,
                t.Raza as raza,
                a.Edad as edad,
                a.Peso as peso,
                a.AlimentoDiario as alimento_diario,
                a.Medicamentos as medicamentos
            FROM Animal a
            LEFT JOIN TipoAnimal t ON a.TipoAnimalId = t.TipoAnimalId
            WHERE a.UsuarioId = ?
            ORDER BY a.AnimalId DESC";

    $stmt = $conexion->prepare($sql);
    $stmt->execute([$id_usuario]);
    $animales = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["status" => "success", "data" => $animales]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Error de base de datos: " . $e->getMessage()]);
}
?>