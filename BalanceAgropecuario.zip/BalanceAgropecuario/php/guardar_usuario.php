<?php

require_once "conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo "Método no permitido.";
    exit;
}

// Capturar los datos originales de forma segura
$nombre = trim($_POST["nombre"] ?? "");
$correo = trim($_POST["correo"] ?? "");
$password = $_POST["password"] ?? "";

// Capturar los nuevos datos integrados del perfil (evitando warnings de "Undefined array key")
$generoId = !empty($_POST["generoId"]) ? $_POST["generoId"] : null;
$tipoDocumentoId = !empty($_POST["tipoDocumentoId"]) ? $_POST["tipoDocumentoId"] : null;
$fechaNacimiento = !empty($_POST["fechaNacimiento"]) ? $_POST["fechaNacimiento"] : null;

$noDocRaw = trim($_POST["noDocumento"] ?? "");
$noDocumento = $noDocRaw !== "" ? $noDocRaw : null;

$celularRaw = trim($_POST["celular"] ?? "");
$celular = $celularRaw !== "" ? $celularRaw : null;

$direccionRaw = trim($_POST["direccion"] ?? "");
$direccion = $direccionRaw !== "" ? $direccionRaw : null;

// Verificar que los campos obligatorios principales estén completos
if ($nombre === "" || $correo === "" || $password === "" || $noDocumento === null || $fechaNacimiento === null) {
    echo "Faltan campos obligatorios.";
    exit;
}

// Verificar que el correo tenga un formato válido
if (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {
    echo "El correo electrónico no es válido.";
    exit;
}

// Verificar si el correo ya está registrado en la tabla Usuario
$sql = "SELECT UsuarioId FROM Usuario WHERE Email = ?";
$stmt = $conexion->prepare($sql);
$stmt->execute([$correo]);

if ($stmt->fetch()) {
    echo "El correo ya está registrado.";
    exit;
}

// Encriptar la contraseña antes de guardarla
$passwordHash = password_hash($password, PASSWORD_DEFAULT);

// Guardar el usuario con todos sus datos unificados
$sql = "INSERT INTO Usuario (Nombre, Apellido, Email, password, estado, GeneroId, TipoDocumentoId, NoDocumento, FechaNacimiento, Celular, Direccion)
        VALUES (?, '', ?, ?, 'Activo', ?, ?, ?, ?, ?, ?)";

$stmt = $conexion->prepare($sql);
$stmt->execute([
    $nombre,
    $correo,
    $passwordHash,
    $generoId,
    $tipoDocumentoId,
    $noDocumento,
    $fechaNacimiento,
    $celular,
    $direccion
]);

echo "Usuario registrado correctamente.";

?>