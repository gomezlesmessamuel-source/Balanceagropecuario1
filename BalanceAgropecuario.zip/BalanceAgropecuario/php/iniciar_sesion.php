<?php
session_start();
require_once "conexion.php";

$correo = trim($_POST["correo"] ?? "");
$password = $_POST["password"] ?? "";

if ($correo === "" || $password === "") {
    echo "Por favor complete todos los campos";
    exit;
}

try {
    $sql = "SELECT UsuarioId, password, estado FROM Usuario WHERE Email = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->execute([$correo]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        // Verificar si la contraseña coincide (soporta password_hash o texto plano durante pruebas)
        $passwordValida = password_verify($password, $usuario["password"]) || ($password === $usuario["password"]);

        if ($passwordValida) {
            // Verificar si está suspendido
            if ($usuario["estado"] === "Suspendido") {
                echo "Tu cuenta ha sido suspendida por tiempo indefinido.";
                exit;
            }

            $_SESSION["id_usuario"] = $usuario["UsuarioId"];
            echo "Inicio de sesión correcto.";
        } else {
            echo "Correo o contraseña incorrectos.";
        }
    } else {
        echo "Correo o contraseña incorrectos.";
    }

} catch (PDOException $e) {
    echo "Error en el servidor: " . $e->getMessage();
}
?>