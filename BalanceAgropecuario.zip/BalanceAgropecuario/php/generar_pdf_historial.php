<?php
session_start();
require_once "conexion.php";

if (!isset($_SESSION["id_usuario"]) || !isset($_GET["id"])) {
    die("Acceso denegado o ID de animal no proporcionado.");
}

$id_usuario = $_SESSION["id_usuario"];
$id_animal = intval($_GET["id"]);

try {
    // 1. Obtener datos del animal asegurando que pertenezca al usuario
    $sqlAnimal = "SELECT a.Nombre, t.Nombre AS Tipo, t.Raza, a.Peso, a.Edad 
                  FROM Animal a 
                  LEFT JOIN TipoAnimal t ON a.TipoAnimalId = t.TipoAnimalId 
                  WHERE a.AnimalId = ? AND a.UsuarioId = ?";
    $stmtAnimal = $conexion->prepare($sqlAnimal);
    $stmtAnimal->execute([$id_animal, $id_usuario]);
    $animal = $stmtAnimal->fetch(PDO::FETCH_ASSOC);

    if (!$animal) {
        die("El animal no existe o no tienes permisos para ver su historial.");
    }

    // 2. Obtener el historial médico completo
    $sqlHistorial = "SELECT Fecha, Diagnostico, Tratamiento, Observaciones 
                     FROM HistorialMedico 
                     WHERE AnimalId = ? 
                     ORDER BY Fecha DESC";
    $stmtHistorial = $conexion->prepare($sqlHistorial);
    $stmtHistorial->execute([$id_animal]);
    $historial = $stmtHistorial->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Error de base de datos: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Historial Médico - <?php echo htmlspecialchars($animal['Nombre']); ?></title>
    <style>
        body { font-family: Arial, sans-serif; padding: 40px; color: #333; line-height: 1.6; }
        .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #0b6623; padding-bottom: 10px; }
        .header h1 { color: #0b6623; margin: 0; }
        .info-box { border: 1px solid #ccc; padding: 20px; margin-bottom: 30px; border-radius: 8px; background-color: #f9f9f9; }
        .info-box h2 { margin-top: 0; color: #0056b3; font-size: 18px; border-bottom: 1px solid #ddd; padding-bottom: 5px; }
        .history-item { border: 1px solid #eee; padding: 15px; margin-bottom: 15px; border-left: 5px solid #17a2b8; background-color: #fff; }
        .history-item strong { color: #333; }
        .fecha-badge { background-color: #17a2b8; color: white; padding: 3px 8px; border-radius: 4px; font-size: 14px; font-weight: bold; }
        
        /* Estilos específicos para cuando se imprime o guarda como PDF */
        @media print {
            body { padding: 0; background-color: white; }
            .info-box, .history-item { box-shadow: none; border: 1px solid #000; }
            .no-print { display: none; } /* Oculta botones al imprimir */
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>Historial Médico del Animal</h1>
        <p>Documento generado el: <strong><?php echo date('Y-m-d H:i:s'); ?></strong></p>
    </div>

    <div class="info-box">
        <h2>Datos Generales</h2>
        <p><strong>Nombre del Animal:</strong> <?php echo htmlspecialchars($animal['Nombre']); ?></p>
        <p><strong>Tipo:</strong> <?php echo htmlspecialchars($animal['Tipo'] ?? 'N/A'); ?> &nbsp;&nbsp;|&nbsp;&nbsp; <strong>Raza:</strong> <?php echo htmlspecialchars($animal['Raza'] ?? 'N/A'); ?></p>
        <p><strong>Peso Registrado:</strong> <?php echo htmlspecialchars($animal['Peso']); ?> kg</p>
    </div>

    <h2 style="color: #0b6623;">Registros Médicos (Histórico)</h2>
    
    <?php if (empty($historial)): ?>
        <p style="text-align: center; color: #666; font-style: italic;">No hay registros médicos para este animal.</p>
    <?php else: ?>
        <?php foreach ($historial as $registro): ?>
            <div class="history-item">
                <p><span class="fecha-badge">Fecha: <?php echo htmlspecialchars($registro['Fecha']); ?></span></p>
                <p><strong>Diagnóstico:</strong> <br><?php echo nl2br(htmlspecialchars($registro['Diagnostico'] ?: 'Ninguno')); ?></p>
                <p><strong>Tratamiento y Dosis:</strong> <br><?php echo nl2br(htmlspecialchars($registro['Tratamiento'] ?: 'Ninguno')); ?></p>
                <p><strong>Observaciones:</strong> <br><?php echo nl2br(htmlspecialchars($registro['Observaciones'] ?: 'Ninguna')); ?></p>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>

    <!-- Botón visible solo en la web, se oculta en el PDF -->
    <div class="no-print" style="text-align: center; margin-top: 40px;">
        <button onclick="window.print()" style="padding: 12px 25px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; font-weight: bold;">
            🖨️ Imprimir / Guardar como PDF
        </button>
        <button onclick="window.close()" style="padding: 12px 25px; background: #6c757d; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; font-weight: bold; margin-left: 10px;">
            ❌ Cerrar Pestaña
        </button>
    </div>

    <script>
        // Abre el cuadro de diálogo de impresión automáticamente apenas carga la página
        window.onload = function() {
            setTimeout(function() {
                window.print();
            }, 500);
        };
    </script>
</body>
</html>