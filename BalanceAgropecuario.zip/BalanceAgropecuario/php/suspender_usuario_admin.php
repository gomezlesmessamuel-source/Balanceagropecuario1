<?php
ob_start();
error_reporting(0);

session_start();
header("Content-Type: application/json; charset=UTF-8");

try {
    if (!file_exists("conexion.php")) {
        throw new Exception("El archivo conexion.php no existe en la carpeta php/");
    }
    require_once "conexion.php";

    $inputJSON = json_decode(file_get_contents("php://input"), true);
    $usuario_id = $inputJSON["usuario_id"] ?? $_POST["usuario_id"] ?? $_GET["usuario_id"] ?? "";

    if (empty($usuario_id)) {
        throw new Exception("ID de usuario no proporcionado.");
    }

    // Agregar columna 'estado' si no existe
    try {
        $conexion->exec("ALTER TABLE Usuario ADD COLUMN estado VARCHAR(20) DEFAULT 'Activo'");
    } catch (PDOException $e) {
        // Ignorar si ya existe
    }

    $stmtSelect = $conexion->prepare("SELECT estado FROM Usuario WHERE UsuarioId = ?");
    $stmtSelect->execute([$usuario_id]);
    $usuario = $stmtSelect->fetch(PDO::FETCH_ASSOC);

    if (!$usuario) {
        throw new Exception("Usuario no encontrado.");
    }

    $estadoActual = (!empty($usuario['estado'])) ? $usuario['estado'] : 'Activo';
    $nuevoEstado = ($estadoActual === 'Suspendido') ? 'Activo' : 'Suspendido';

    $stmtUpdate = $conexion->prepare("UPDATE Usuario SET estado = ? WHERE UsuarioId = ?");
    $stmtUpdate->execute([$nuevoEstado, $usuario_id]);

    ob_clean();
    echo json_encode([
        "status" => "success",
        "nuevoEstado" => $nuevoEstado,
        "message" => "Estado modificado a: " . $nuevoEstado
    ]);
    exit;

} catch (Exception $e) {
    ob_clean();
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
    exit;
}
?>