<?php
session_start();
require_once "conexion.php";
header("Content-Type: application/json; charset=UTF-8");

try {
    $sql = "SELECT 
                u.UsuarioId as id_usuario,
                u.UsuarioId,
                u.Nombre as nombre,
                u.Correo as correo,
                COALESCE(u.estado, 'Activo') as estado,
                COUNT(a.AnimalId) as total_animales
            FROM Usuario u
            LEFT JOIN Animal a ON u.UsuarioId = a.UsuarioId
            GROUP BY u.UsuarioId";

    $stmt = $conexion->prepare($sql);
    $stmt->execute();
    $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(["status" => "success", "data" => $usuarios]);
} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => $e->getMessage()]);
}
?>