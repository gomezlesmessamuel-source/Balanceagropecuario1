<?php
session_start();
require_once "conexion.php";

if (!isset($_SESSION["id_usuario"])) {
    echo "No hay una sesión iniciada.";
    exit;
}

$id_usuario = $_SESSION["id_usuario"];
$datos = json_decode(file_get_contents("php://input"), true);

if (!$datos) {
    echo "No se recibieron datos válidos.";
    exit;
}

$generoId = !empty($datos["generoId"]) ? intval($datos["generoId"]) : null;
$tipoDocumentoId = !empty($datos["tipoDocumentoId"]) ? intval($datos["tipoDocumentoId"]) : null;
$noDocumento = !empty($datos["noDocumento"]) ? $datos["noDocumento"] : null;
$fechaNacimiento = !empty($datos["fechaNacimiento"]) ? $datos["fechaNacimiento"] : null;
$celular = trim($datos["celular"] ?? "");
$direccion = trim($datos["direccion"] ?? "");

try {
    $sql = "UPDATE Usuario 
            SET GeneroId = ?, TipoDocumentoId = ?, NoDocumento = ?, FechaNacimiento = ?, Celular = ?, Direccion = ? 
            WHERE UsuarioId = ?";
    $stmt = $conexion->prepare($sql);
    $stmt->execute([$generoId, $tipoDocumentoId, $noDocumento, $fechaNacimiento, $celular, $direccion, $id_usuario]);

    echo "Perfil actualizado correctamente.";
} catch (PDOException $e) {
    echo "Error al actualizar perfil: " . $e->getMessage();
}
?>