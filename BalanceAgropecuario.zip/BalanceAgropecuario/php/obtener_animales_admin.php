<?php
require_once "conexion.php";
header("Content-Type: application/json; charset=UTF-8");

try {
    $sql = "SELECT 
                a.AnimalId, 
                a.Nombre AS NombreAnimal, 
                a.Sexo,
                a.Edad,
                a.Peso,
                a.UsuarioId, 
                CONCAT(u.Nombre, ' ', IFNULL(u.Apellido, '')) AS NombreDueno,
                u.Email AS CorreoDueno,
                ta.Nombre AS Tipo,
                ta.Raza AS Raza,
                (SELECT MIN(v.ProximaDosis) 
                 FROM Vacunacion v 
                 WHERE v.AnimalId = a.AnimalId AND v.ProximaDosis >= CURDATE()) AS SiguienteDosis
            FROM Animal a
            INNER JOIN Usuario u ON a.UsuarioId = u.UsuarioId
            LEFT JOIN TipoAnimal ta ON a.TipoAnimalId = ta.TipoAnimalId";
            
    $stmt = $conexion->query($sql);
    $animales = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        "status" => "success",
        "data" => $animales
    ]);
} catch (PDOException $e) {
    echo json_encode([
        "status" => "error",
        "message" => "Error al obtener animales: " . $e->getMessage()
    ]);
}
?>