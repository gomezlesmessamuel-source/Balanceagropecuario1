<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login Administrador</title>
    <link rel="stylesheet" href="css/RegistroUser.css"> <!-- O tu CSS correspondiente -->
</head>
<body class="registro-body">
    <div class="registro-contenedor">
        <h2>Ingreso Administrador</h2>
        <!-- Los IDs deben coincidir con los que leerá JavaScript -->
        <input id="adminUsuarioLogin" type="text" placeholder="Usuario">
        <input id="adminPassLogin" type="password" placeholder="Contraseña">
        
        <button onclick="loginAdministrador()">Entrar al Panel</button>
        <br><br>
        <a href="registro.php">Volver al inicio</a>
    </div>
    <script src="script.js"></script>
</body>
</html>