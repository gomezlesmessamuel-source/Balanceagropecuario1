DROP DATABASE IF EXISTS balance_agropecuario;
CREATE DATABASE balance_agropecuario;
USE balance_agropecuario;

CREATE TABLE TipoDocumento (
    TipoDocumentoId INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL
);

CREATE TABLE TipoAnimal (
    TipoAnimalId INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL,
    Raza VARCHAR(100) NOT NULL DEFAULT 'General',
    CONSTRAINT uq_tipo_raza UNIQUE (Nombre, Raza)
);

CREATE TABLE Medicamento (
    MedicamentosId INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL UNIQUE,
    Descripcion TEXT,
    DosisBase INT
);

CREATE TABLE Alimento (
    AlimentoId INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(100) NOT NULL UNIQUE,
    Tipo VARCHAR(100),
    CantidadBase INT
);

CREATE TABLE administradores (
    id_administrador INT AUTO_INCREMENT PRIMARY KEY,
    usuario VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE Genero (
    GeneroId INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(20) NOT NULL
);

INSERT INTO Genero (Nombre) VALUES ('Masculino'), ('Femenino'), ('Otro');

CREATE TABLE Usuario (
    UsuarioId INT AUTO_INCREMENT PRIMARY KEY,
    Nombre VARCHAR(50) NOT NULL,
    Apellido VARCHAR(50) NULL,
    GeneroId INT NULL,
    TipoDocumentoId INT NULL,
    NoDocumento BIGINT NULL,
    FechaNacimiento DATE NULL,
    Email VARCHAR(100) NOT NULL UNIQUE,
    Celular VARCHAR(50) NULL,
    Direccion VARCHAR(100) NULL,
    password VARCHAR(255) NOT NULL,
    estado VARCHAR(20) DEFAULT 'Activo',
    
    FOREIGN KEY (TipoDocumentoId) REFERENCES TipoDocumento(TipoDocumentoId) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (GeneroId) REFERENCES Genero(GeneroId) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Animal (
    AnimalId INT AUTO_INCREMENT PRIMARY KEY,
    UsuarioId INT NOT NULL,
    TipoAnimalId INT NOT NULL,
    Nombre VARCHAR(100) NULL,
    Sexo VARCHAR(10) NULL,
    Edad INT NULL,
    Peso DECIMAL(10,2) NULL,
    AlimentoDiario VARCHAR(100) NULL,
    Medicamentos TEXT NULL,
    AlimentoId INT NULL,
    MedicamentoId INT NULL,
    Observaciones TEXT NULL,
    FechaRegistro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    HistorialMedicoId INT NULL,
    
    FOREIGN KEY (UsuarioId) REFERENCES Usuario(UsuarioId) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (TipoAnimalId) REFERENCES TipoAnimal(TipoAnimalId) ON DELETE RESTRICT ON UPDATE CASCADE,
    FOREIGN KEY (AlimentoId) REFERENCES Alimento(AlimentoId) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (MedicamentoId) REFERENCES Medicamento(MedicamentosId) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE HistorialMedico (
    HistorialId INT AUTO_INCREMENT PRIMARY KEY,
    AnimalId INT NOT NULL,
    Fecha DATE NOT NULL,
    Diagnostico TEXT,
    Tratamiento TEXT,
    Observaciones TEXT,
    FOREIGN KEY (AnimalId) REFERENCES Animal(AnimalId) ON DELETE CASCADE ON UPDATE CASCADE
);

ALTER TABLE Animal 
    ADD CONSTRAINT fk_animal_historial
    FOREIGN KEY (HistorialMedicoId) REFERENCES HistorialMedico(HistorialId) ON DELETE SET NULL ON UPDATE CASCADE;

CREATE TABLE Vacunacion (
    VacunacionId INT AUTO_INCREMENT PRIMARY KEY,
    AnimalId INT NOT NULL,
    MedicamentoId INT NULL,
    NombreVacuna VARCHAR(100) NOT NULL,
    FechaAplicacion DATE NOT NULL,
    ProximaDosis DATE NULL,
    FOREIGN KEY (AnimalId) REFERENCES Animal(AnimalId) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (MedicamentoId) REFERENCES Medicamento(MedicamentosId) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE Produccion (
    ProduccionId INT AUTO_INCREMENT PRIMARY KEY,
    AnimalId INT NOT NULL,
    Fecha DATE NOT NULL,
    MedicamentoId INT,
    Dosis INT,
    DosisCalculada INT,
    AlimentoId INT,
    FOREIGN KEY (AnimalId) REFERENCES Animal(AnimalId) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (MedicamentoId) REFERENCES Medicamento(MedicamentosId) ON DELETE SET NULL ON UPDATE CASCADE,
    FOREIGN KEY (AlimentoId) REFERENCES Alimento(AlimentoId) ON DELETE SET NULL ON UPDATE CASCADE
);

CREATE TABLE ControlPeso (
    ControlId INT AUTO_INCREMENT PRIMARY KEY,
    AnimalId INT NOT NULL,
    Fecha DATE NOT NULL,
    Peso DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (AnimalId) REFERENCES Animal(AnimalId) ON DELETE CASCADE ON UPDATE CASCADE
);

INSERT INTO TipoDocumento (Nombre) VALUES ('Cédula de Ciudadanía'), ('Tarjeta de Identidad'), ('Cédula de Extranjería');
INSERT INTO administradores (usuario, password) VALUES ('BalanceAgro@gmail.com', '12345');

-- NUEVO: Inserción de medicamentos base
INSERT INTO Medicamento (Nombre, Descripcion, DosisBase) VALUES 
('Ivermectina', 'Desparasitante interno y externo', 2),
('Oxitetraciclina', 'Antibiótico de amplio espectro', 5),
('Vitamina ADE', 'Suplemento vitamínico', 3),
('Tilmicosina', 'Tratamiento de infecciones respiratorias', 10),
('Penicilina', 'Antibiótico para infecciones bacterianas', 4);