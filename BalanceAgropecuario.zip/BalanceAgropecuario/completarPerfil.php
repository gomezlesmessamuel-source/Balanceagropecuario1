<?php
session_start();
if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Completar Información Usuario</title>
    <link rel="stylesheet" href="css/registroAniaml.css">
</head>
<body class="animal-body">
    <div class="main-wrapper" style="justify-content: center;">
        <div class="panel-registro" style="max-width: 500px; width: 100%;">
            <h1>Información del Usuario</h1>

            <label style="display:block; text-align:left; margin-bottom:3px;">Género:</label>
            <select id="generoId" style="width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;">
                <option value="1">Masculino</option>
                <option value="2">Femenino</option>
                <option value="3">Otro</option>
            </select>
            
            <label style="display:block; text-align:left; margin-bottom:3px;">Tipo de Documento:</label>
            <select id="tipoDocumento" style="width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;">
                <option value="1">Cédula de Ciudadanía</option>
                <option value="2">Tarjeta de Identidad</option>
                <option value="3">Cédula de Extranjería</option>
            </select>

            <label style="display:block; text-align:left; margin-bottom:3px;">Número de Documento:</label>
            <input id="noDocumento" type="number" placeholder="Ej. 1012345678">

            <label style="display:block; text-align:left; margin-bottom:3px;">Fecha de Nacimiento:</label>
            <input id="fechaNacimiento" type="date">

            <label style="display:block; text-align:left; margin-bottom:3px;">Teléfono / Celular:</label>
            <input id="celular" type="text" placeholder="Ej. 3001234567">

            <label style="display:block; text-align:left; margin-bottom:3px;">Dirección:</label>
            <input id="direccion" type="text" placeholder="Ej. Calle 123 #45-67">

            <button class="btn-guardar" onclick="guardarPerfil()">Guardar Información</button>
            
            <div class="footer-links" style="margin-top: 15px;">
                <a href="AnimalRegistro.php">Volver al Registro de Animales</a>
            </div>
        </div>
    </div>

    <script>
        function guardarPerfil() {
            const datos = {
                generoId: document.getElementById("generoId").value,
                tipoDocumentoId: document.getElementById("tipoDocumento").value,
                noDocumento: document.getElementById("noDocumento").value,
                fechaNacimiento: document.getElementById("fechaNacimiento").value,
                celular: document.getElementById("celular").value,
                direccion: document.getElementById("direccion").value
            };

            if (!datos.noDocumento || !datos.fechaNacimiento) {
                alert("Por favor complete los campos obligatorios.");
                return;
            }

            fetch("php/guardar_perfil_usuario.php", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(datos)
            })
            .then(res => res.text())
            .then(respuesta => {
                alert(respuesta);
                if (respuesta.trim() === "Perfil actualizado correctamente.") {
                    window.location.href = "AnimalRegistro.php";
                }
            });
        }
    </script>
</body>
</html>