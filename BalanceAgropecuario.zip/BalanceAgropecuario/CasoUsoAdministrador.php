```html
<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<title>Sistema Agropecuario</title>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background-color: #e4f3eb;
}

/* Pantalla inicial */
.inicio {
    height: 100vh;
    background: url(BalanceAgropecuario.JPEG)no-repeat center center/cover;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
}

/* Botón */
.btn-login {
    margin-top: 20px;
    padding: 12px 20px;
    border: none;
    background-color: #2e7d32;
    color: white;
    font-size: 16px;
    border-radius: 8px;
    cursor: pointer;
}

.btn-login:hover {
    background-color: #1b5e20;
}

/* Panel admin */
.admin {
    display: none;
    padding: 20px;
}

header {
    background-color: #2e7d32;
    color: white;
    padding: 10px;
    text-align: center;
}

.card {
    background: white;
    margin: 15px 0;
    padding: 15px;
    border-radius: 10px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}

button {
    margin: 5px;
    padding: 8px 12px;
    border: none;
    background-color: #66bb6a;
    color: white;
    border-radius: 6px;
    cursor: pointer;
}

button:hover {
    background-color: #388e3c;
}
</style>

</head>
<body>

<!-- Pantalla de inicio -->
<div class="inicio" id="inicio">
    <!-- Aquí luego puedes poner tu logo -->
    <h1 style="color:white;">Sistema Agropecuario</h1>
    <button class="btn-login" onclick="entrar()">Iniciar sesión administrador</button>
</div>

<!-- Panel Administrador -->
<div class="admin" id="admin">
    <header>
        <h2>Panel Administrador</h2>
    </header>

    <div class="card">
        <h3>Reportes</h3>
        <button>Generar Reportes</button>
        <button>Consultar Reportes</button>
    </div>

    <div class="card">
        <h3>Supervisión de Datos</h3>
        <button>Validar Datos</button>
        <button>Corregir Datos</button>
        <button>Datos Corregidos</button>
    </div>

    <div class="card">
        <h3>Gestión del Sistema</h3>
        <button>Supervisar Sistema</button>
        <button>Registro</button>
        <button>Animales</button>
    </div>

    <div class="card">
        <h3>Gestión de Usuarios</h3>
        <button>Crear Usuario</button>
        <button>Editar Usuario</button>
        <button>Eliminar Usuario</button>
    </div>
    
</div>

<script>
function entrar() {
    document.getElementById("inicio").style.display = "none";
    document.getElementById("admin").style.display = "block";
}
</script>

</body>
</html>
```
