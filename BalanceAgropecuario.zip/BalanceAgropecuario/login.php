<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Login Usuario</title>
    <link rel="stylesheet" href="css/LoginUser.css">
</head>
<body class="login-body">

    <div class="login-contenedor">
        <h2>Login Usuario</h2>

        <!-- Mensaje de suspensión correctamente ubicado dentro del contenedor -->
        <?php if (isset($_GET['error']) && $_GET['error'] === 'suspendido'): ?>
            <div style="background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; padding: 10px 15px; border-radius: 5px; margin-bottom: 15px; text-align: center; font-weight: bold; font-size: 14px;">
                Su cuenta ha sido suspendida por tiempo indefinido.
            </div>
        <?php endif; ?>

        <input id="correoLogin" type="email" placeholder="Correo">
        <input id="contraseñaLogin" type="password" placeholder="Contraseña">
        <button onclick="login()">Ingresar</button>
        <br><br>
        <a href="registro.php">Registrarse</a>
    </div>

    
    
    <script src="script.js"></script>
</body>
</html>