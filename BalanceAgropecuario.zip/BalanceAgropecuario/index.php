<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Balance Agropecuario - Gestión Integral</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <header>
        <h1>Balance Agropecuario</h1>
        <nav>
            <a href="#inicio">Inicio</a>
            <a href="#servicios">Servicios</a>
            <a href="#productos">Productos</a>
            <a href="#contacto">Contacto</a>
            <a href="login.php" style="color: #fff;">Ingresar</a>
            <a href="registro.php" class="btn btn-primary" style="padding: 6px 12px;">Registrarse</a>
        </nav>
    </header>

    <section id="inicio" class="hero">
        <div class="hero-content">
            <h2>Soluciones agrícolas para un futuro sostenible</h2>
            <p>Optimiza el rendimiento de tu campo mediante nuestro sistema inteligente de control de peso, alimentación e historial médico animal.</p>
            <a href="login.php" class="btn btn-primary">Gestionar Mis Animales</a>
            <a href="#servicios" class="btn btn-secondary">Conocer Más</a>
        </div>
    </section>

    <section id="servicios" class="section-container">
        <h2>Nuestros Servicios</h2>
        <div class="grid-layout">
            <div class="card">
                <h3>Nutrición Avanzada</h3>
                <p>Monitoreo y asignación de planes de alimentación balanceada para tu ganado.</p>
            </div>
            <div class="card">
                <h3>Control de Peso</h3>
                <p>Seguimiento estricto del crecimiento y curvas de rendimiento productivo.</p>
            </div>
            <div class="card">
                <h3>Historial Médico</h3>
                <p>Prevención de enfermedades mediante el registro y cálculo de medicamentos necesarios.</p>
            </div>
            <div class="card">
                <h3>Reportes Seguros</h3>
                <p>Almacenamiento de datos seguro con acceso inmediato desde tu celular o computadora.</p>
            </div>
        </div>
    </section>

    <section id="productos" class="section-container" style="background-color: #fff;">
        <h2>Productos Recomendados</h2>
        <div class="grid-layout">
            <div class="card" style="border-top-color: #f39c12;">
                <h3>Suplementos Nutricionales</h3>
                <p>Optimiza la digestión y acelera el desarrollo óptimo de peso diario.</p>
            </div>
            <div class="card" style="border-top-color: #f39c12;">
                <h3>Kits de Monitoreo</h3>
                <p>Herramientas y básculas digitales compatibles con nuestro software de gestión.</p>
            </div>
            <div class="card" style="border-top-color: #f39c12;">
                <h3>Medicamentos Base</h3>
                <p>Tratamientos aprobados para el control sanitario preventivo en fincas.</p>
            </div>
        </div>
    </section>

    <section id="contacto" class="contacto-block">
        <div class="info-contacto">
            <h2>Contáctanos</h2>
            <p>¿Tienes dudas sobre el uso de la plataforma o necesitas soporte técnico para tu finca?</p>
            <p><strong>Teléfono:</strong> +57 300 123 4567</p>
            <p><strong>Correo:</strong> soporte@balanceagropecuario.com</p>
            <p><strong>Horario:</strong> Lunes a Viernes - 8:00 AM a 5:00 PM</p>
        </div>
        
        <div class="form-contacto">
            <h3>Envíanos un Mensaje</h3>
            <input type="text" placeholder="Tu Nombre Completo">
            <input type="email" placeholder="Tu Correo Electrónico">
            <input type="text" placeholder="Asunto">
            <textarea rows="4" placeholder="Escribe tu mensaje aquí..."></textarea>
            <button class="btn btn-primary" style="width: 100%; border: none; cursor: pointer;">Enviar Mensaje</button>
        </div>
    </section>

    <footer>
        <p>&copy; <?php echo date("Y"); ?> Balance Agropecuario. Todos los derechos reservados.</p>
        <p>
            <a href="#">Política de Privacidad</a> | 
            <a href="#">Términos y Condiciones</a>
        </p>
    </footer>

</body>
</html>