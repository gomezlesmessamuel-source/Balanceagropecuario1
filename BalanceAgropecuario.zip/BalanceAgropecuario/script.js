// ==========================================
// LOGIN DE USUARIO
// ==========================================

function login() {
    const correo = document.getElementById("correoLogin").value.trim();
    const password = document.getElementById("contraseñaLogin").value;

    if (correo === "" || password === "") {
        alert("Por favor complete todos los campos");
        return;
    }

    fetch("php/iniciar_sesion.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams({
            correo: correo,
            password: password
        })
    })
    .then(response => response.text())
    .then(resultado => {
        if (resultado.trim() === "Inicio de sesión correcto.") {
            alert("Inicio de sesión correcto.");
            window.location.href = "AnimalRegistro.php";
        } else {
            alert(resultado);
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("No se pudo conectar con el servidor.");
    });
}

// ==========================================
// REGISTRO DE USUARIOS
// ==========================================

function registrar() {
    const nombre = document.getElementById("nombre").value.trim();
    const correo = document.getElementById("correo").value.trim();
    const password = document.getElementById("contraseña").value;
    const generoId = document.getElementById("generoId").value;
    const tipoDocumentoId = document.getElementById("tipoDocumento").value;
    const noDocumento = document.getElementById("noDocumento").value;
    const fechaNacimiento = document.getElementById("fechaNacimiento").value;
    const celular = document.getElementById("celular").value.trim();
    const direccion = document.getElementById("direccion").value.trim();

    if (nombre === "" || correo === "" || password === "" || noDocumento === "" || fechaNacimiento === "") {
        alert("Por favor rellene todos los campos obligatorios");
        return;
    }

    if (/[0-9@]/.test(nombre)) {
        alert("Error: El nombre no debe contener números ni el símbolo @");
        return;
    }

    if (!correo.includes("@")) {
        alert("Error: El correo debe contener el símbolo @");
        return;
    }

    fetch("php/guardar_usuario.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded"
        },
        body: new URLSearchParams({
            nombre: nombre,
            correo: correo,
            password: password,
            generoId: generoId,
            tipoDocumentoId: tipoDocumentoId,
            noDocumento: noDocumento,
            fechaNacimiento: fechaNacimiento,
            celular: celular,
            direccion: direccion
        })
    })
    .then(response => response.text())
    .then(resultado => {
        alert(resultado);
        if (resultado.trim() === "Usuario registrado correctamente.") {
            window.location.href = "login.php";
        }
    })
    .catch(error => {
        console.error(error);
        alert("No se pudo conectar con el servidor.");
    });
}

// ==========================================
// GESTIÓN DE ANIMALES (ESTADO Y LIMPIEZA)
// ==========================================

let animalEnModificacion = null;

function limpiarFormularioAnimal() {
    animalEnModificacion = null;
    const campos = [
        "animalNombre", "animalTipo", "animalRaza", "animalEdad", 
        "animalPeso", "animalAlimento", "animalDosis", 
        "animalProximaDosis", "animalDiagnostico", "animalObservaciones"
    ];
    campos.forEach(id => {
        const el = document.getElementById(id);
        if (el) el.value = "";
    });
    
    if (document.getElementById("animalSexo")) document.getElementById("animalSexo").value = "";
    if (document.getElementById("animalMedicamento")) document.getElementById("animalMedicamento").value = "";
}

// ==========================================
// GUARDAR / MODIFICAR ANIMAL
// ==========================================

function guardarAnimal() {
    const nombre = document.getElementById("animalNombre")?.value.trim() || "";
    const tipo = document.getElementById("animalTipo")?.value.trim() || "";
    const raza = document.getElementById("animalRaza")?.value.trim() || "";
    const sexo = document.getElementById("animalSexo")?.value || "";
    const edad = document.getElementById("animalEdad")?.value || "";
    const peso = document.getElementById("animalPeso")?.value || "";
    const alimento = document.getElementById("animalAlimento")?.value.trim() || "";
    
    // Cambios para enviar Id y Nombre del medicamento
    const selectMed = document.getElementById('animalMedicamento');
    const medicamento_id = selectMed?.value || "";
    const medicamento_nombre = selectMed && selectMed.selectedIndex > 0 ? selectMed.options[selectMed.selectedIndex].getAttribute('data-nombre') : "";

    const dosis = document.getElementById("animalDosis")?.value || "";
    const proximaDosis = document.getElementById("animalProximaDosis")?.value || "";
    const diagnostico = document.getElementById("animalDiagnostico")?.value.trim() || "";
    const observaciones = document.getElementById("animalObservaciones")?.value.trim() || "";

    if (nombre === "" || tipo === "" || peso === "") {
        alert("Por favor complete los campos obligatorios (Nombre, Tipo y Peso).");
        return;
    }

    const payload = {
        animal_id: animalEnModificacion,
        nombre: nombre,
        tipo: tipo,
        raza: raza,
        sexo: sexo,
        edad: edad,
        peso: peso,
        alimento_diario: alimento,
        medicamento_id: medicamento_id,
        medicamento_nombre: medicamento_nombre,
        dosis: dosis,
        proxima_dosis: proximaDosis,
        diagnostico: diagnostico,
        observaciones: observaciones
    };

    const url = animalEnModificacion !== null ? "php/modificar_animal.php" : "php/guardar_animal.php";

    fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
    })
    .then(response => response.text())
    .then(resultado => {
        const resTrim = resultado.trim();
        if (resTrim === "OK" || resTrim.includes("correctamente") || resTrim.includes("éxito")) {
            alert(animalEnModificacion !== null ? "Animal modificado correctamente." : "Animal guardado correctamente.");
            limpiarFormularioAnimal();
            cargarAnimal();
        } else {
            alert(resultado);
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("No se pudo conectar con el servidor.");
    });
}

// ==========================================
// ELIMINACIÓN DE ANIMAL
// ==========================================

function eliminarAnimal(idAnimal) {
    if (confirm("¿Estás seguro de que deseas eliminar este registro de animal?")) {
        fetch("php/eliminar_animal.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ animal_id: idAnimal })
        })
        .then(response => response.json())
        .then(resultado => {
            alert(resultado.message);
            if (resultado.status === "success") {
                cargarAnimal();
            }
        })
        .catch(error => {
            console.error("Error al eliminar el animal:", error);
            alert("No se pudo conectar con el servidor.");
        });
    }
}

// ==========================================
// CARGAR TODOS LOS ANIMALES
// ==========================================

function cargarAnimal() {
    fetch("php/obtener_animal.php?t=" + Date.now())
    .then(response => response.json())
    .then(resultado => {
        const detalle = document.getElementById("detalleAnimal");
        if (!detalle) return;

        if (resultado.status === "success" && Array.isArray(resultado.data)) {
            detalle.innerHTML = "";
            resultado.data.forEach(animal => {
                const tarjeta = document.createElement("div");
                tarjeta.className = "animal-card";
                tarjeta.innerHTML = `
                    <div class="animal-resumen">
                        <h3>${animal.nombre}</h3>
                        <p>${animal.tipo} ${animal.raza ? '| Raza: ' + animal.raza : ''}</p>
                    </div>
                    <div class="animal-botones">
                        <button type="button" onclick="modificarAnimal(${animal.id_animal})">Modificar</button>
                        <button type="button" onclick="verInformacionAnimal(${animal.id_animal})">Información del animal</button>
                        <button type="button" onclick="eliminarAnimal(${animal.id_animal})" style="background-color: #dc3545; color: white;">Eliminar</button>
                    </div>
                `;
                detalle.appendChild(tarjeta);
            });
        } else if (resultado.status === "empty") {
            detalle.innerHTML = `<p style="color: #888;">No hay animales guardados aún.</p>`;
        } else {
            detalle.innerHTML = `<p style="color: red;">${resultado.message}</p>`;
        }
    })
    .catch(error => console.error("Error al cargar animales:", error));
}

// ==========================================
// MODIFICAR ANIMAL (CARGAR EN FORMULARIO)
// ==========================================

function modificarAnimal(idAnimal) {
    fetch("php/obtener_animal.php?id_animal=" + encodeURIComponent(idAnimal))
    .then(response => response.json())
    .then(resultado => {
        if (resultado.status !== "success") {
            alert(resultado.message);
            return;
        }

        const animal = resultado.data;
        animalEnModificacion = animal.id_animal || animal.AnimalId;

        if (document.getElementById("animalNombre")) document.getElementById("animalNombre").value = animal.nombre || "";
        if (document.getElementById("animalTipo")) document.getElementById("animalTipo").value = animal.tipo || "";
        if (document.getElementById("animalRaza")) document.getElementById("animalRaza").value = animal.raza || "";
        if (document.getElementById("animalSexo")) document.getElementById("animalSexo").value = animal.sexo || "";
        if (document.getElementById("animalEdad")) document.getElementById("animalEdad").value = animal.edad || "";
        if (document.getElementById("animalPeso")) document.getElementById("animalPeso").value = animal.peso || "";
        if (document.getElementById("animalAlimento")) document.getElementById("animalAlimento").value = animal.alimento_diario || "";
        
        if (document.getElementById("animalMedicamento")) document.getElementById("animalMedicamento").value = animal.MedicamentoId || "";
        if (typeof calcularDosis === "function") calcularDosis(); // Auto-recalcular la dosis

        if (document.getElementById("animalProximaDosis")) document.getElementById("animalProximaDosis").value = animal.proxima_dosis || "";
        if (document.getElementById("animalDiagnostico")) document.getElementById("animalDiagnostico").value = animal.diagnostico || "";
        if (document.getElementById("animalObservaciones")) document.getElementById("animalObservaciones").value = animal.observaciones || "";

        alert("Puedes modificar la información de " + animal.nombre + ". Después pulsa 'Guardar Animal'.");
    })
    .catch(error => {
        console.error("Error:", error);
        alert("No se pudo cargar la información del animal.");
    });
}

// ==========================================
// VER INFORMACIÓN DETALLADA
// ==========================================

function verInformacionAnimal(idAnimal) {
    fetch("php/obtener_animal.php?id_animal=" + encodeURIComponent(idAnimal))
    .then(response => response.json())
    .then(resultado => {
        if (resultado.status !== "success") {
            alert(resultado.message);
            return;
        }

        const animal = resultado.data;
        const detalle = document.getElementById("detalleAnimal");

        detalle.innerHTML = `
            <div class="info-item"><span class="info-label">Nombre:</span> <span class="info-value">${animal.nombre}</span></div>
            <div class="info-item"><span class="info-label">Tipo:</span> <span class="info-value">${animal.tipo}</span></div>
            <div class="info-item"><span class="info-label">Raza:</span> <span class="info-value">${animal.raza || 'N/A'}</span></div>
            <div class="info-item"><span class="info-label">Peso:</span> <span class="info-value">${animal.peso} kg</span></div>
            <div class="info-item"><span class="info-label">Alimento diario:</span> <span class="info-value">${animal.alimento_diario || 'N/A'}</span></div>
            <div class="info-item"><span class="info-label">Medicamento:</span> <span class="info-value">${animal.medicamentos || 'Ninguno'} (Dosis: ${animal.dosis || 'N/A'})</span></div>
            <div class="info-item"><span class="info-label">Próxima Dosis:</span> <span class="info-value">${animal.proxima_dosis || 'Sin fecha programada'}</span></div>
            <div class="info-item"><span class="info-label">Observaciones:</span> <span class="info-value">${animal.observaciones || 'Ninguna'}</span></div>
            <div style="margin-top: 15px;">
                <button type="button" onclick="cargarAnimal()">Volver a todos los animales</button>
                <!-- BOTÓN PARA DESCARGAR PDF -->
                <button type="button" onclick="descargarHistorialPDF(${animal.id_animal})" style="background-color: #007bff; color: white; margin-left: 5px;">📄 Descargar Historial PDF</button>
            </div>
        `;
    })
    .catch(error => {
        console.error(error);
        alert("No se pudo cargar la información.");
    });
}

// ==========================================
// DESCARGAR PDF DEL HISTORIAL (NUEVO)
// ==========================================
function descargarHistorialPDF(idAnimal) {
    // Esto llamará al archivo PHP encargado de compilar el PDF de Historial Medico
    window.open('php/exportar_historial.php?animal_id=' + idAnimal, '_blank');
}

// ==========================================
// CERRAR SESIÓN
// ==========================================

function cerrarSesion() {
    if (confirm("¿Desea cerrar sesión?")) {
        window.location.href = "login.php";
    }
}

// ==========================================
// ADMINISTRACIÓN Y PANEL ADMIN
// ==========================================

function loginAdministrador() {
    const usuario = document.getElementById("adminUsuarioLogin").value.trim();
    const password = document.getElementById("adminPassLogin").value;

    if (usuario === "" || password === "") {
        alert("Por favor complete todos los campos");
        return;
    }

    fetch("php/iniciar_sesion_admin.php", { 
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({ usuario: usuario, password: password })
    })
    .then(response => response.text())
    .then(resultado => {
        if (resultado.trim() === "Inicio de sesión correcto.") {
            window.location.href = "panelAdministrador.php";
        } else {
            alert(resultado);
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("No se pudo conectar con el servidor.");
    });
}