<?php
session_start();
require_once "php/conexion.php";

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

$id_usuario =$_SESSION["id_usuario"];

// Verificación de suspensión en tiempo real
$stmtEstado =$conexion->prepare("SELECT estado, Nombre FROM Usuario WHERE UsuarioId = ?");
$stmtEstado->execute([$id_usuario]);
$usuarioActual =$stmtEstado->fetch(PDO::FETCH_ASSOC);

if (!$usuarioActual or $usuarioActual['estado'] === 'Suspendido') {
    session_unset();
    session_destroy();
    header("Location: login.php?error=suspendido");
    exit;
}

// Obtener los medicamentos para la lista desplegable
$stmtMed =$conexion->query("SELECT MedicamentosId, Nombre, DosisBase FROM Medicamento");
$medicamentos =$stmtMed->fetchAll(PDO::FETCH_ASSOC);

// Obtener animales del usuario
$sqlAnimales = "SELECT a.AnimalId, a.Nombre, a.Sexo, a.Edad, a.Peso, 
                       ta.Nombre AS TipoNombre, ta.Raza AS RazaNombre,
                       (SELECT MIN(v.ProximaDosis) FROM Vacunacion v WHERE v.AnimalId = a.AnimalId AND v.ProximaDosis >= CURDATE()) AS SiguienteDosis 
                FROM Animal a 
                LEFT JOIN TipoAnimal ta ON a.TipoAnimalId = ta.TipoAnimalId
                WHERE a.UsuarioId = ?
                ORDER BY a.AnimalId DESC";
$stmtAnim = $conexion->prepare($sqlAnimales);
$stmtAnim->execute([$id_usuario]);
$misAnimales =$stmtAnim->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro y Gestión de Animales</title>
    <link rel="stylesheet" href="css/registroAniaml.css">
    <style>
        .validacion-formulario { margin: 8px 0; font-size: 14px; }
        .campo-valido { border: 2px solid #198754 !important; }
        .campo-invalido { border: 2px solid #dc3545 !important; }
        .check-valido { color: #198754; font-weight: bold; }
        .validacion-mensaje { display:block; margin: -5px 0 8px; }
        .btn-accion { padding: 6px 12px; margin-top: 5px; border: none; border-radius: 4px; cursor: pointer; font-weight: bold; }
        .btn-editar { background-color: #036e15; color: #ffffff; }
        .btn-pdf { background-color: #17a2b8; color: white; margin-left: 5px; }
        .btn-eliminar { background-color: #dc3545; color: white; margin-left: 5px; }
        .btn-cancelar { background-color: #6c757d; color: white; display: none; width: 100%; margin-top: 8px; }
    </style>
</head>
<body class="animal-body">
    <div style="max-width: 1100px; margin: 20px auto; padding: 0 15px;">
        <div style="display: flex; justify-content: space-between; align-items: center; background: white; padding: 15px 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
            <h2>Bienvenido, <?php echo htmlspecialchars($usuarioActual['Nombre']); ?></h2>
            <a href="php/cerrar_sesion.php" style="color: #dc3545; font-weight: bold; text-decoration: none;">Cerrar Sesión</a>
        </div>

        <div class="main-wrapper" style="display: flex; gap: 20px;">
            <!-- FORMULARIO DE REGISTRO / EDICIÓN -->
            <div class="panel-registro" style="flex: 1; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2 id="tituloFormulario">Registrar Nuevo Animal</h2>
                
                <input type="hidden" id="animalId" value="">

                <input id="animalNombre" type="text" placeholder="Nombre del animal">
                <select id="animalTipo" required style="width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;">
                    <option value="">Seleccione el tipo de animal</option>
                    <option value="Vaca">Vaca</option><option value="Toro">Toro</option><option value="Ternero">Ternero</option>
                    <option value="Cerdo">Cerdo</option><option value="Caballo">Caballo</option><option value="Yegua">Yegua</option>
                    <option value="Oveja">Oveja</option><option value="Cabra">Cabra</option><option value="Gallina">Gallina</option>
                    <option value="Gallo">Gallo</option><option value="Pato">Pato</option><option value="Conejo">Conejo</option>
                    <option value="Otro">Otro</option>
                </select>
                <input id="animalRaza" type="text" placeholder="Raza (Ej. Bos taurus)">
                <select id="animalSexo" style="width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;">
                    <option value="">Seleccione el sexo</option>
                    <option value="Macho">Macho</option>
                    <option value="Hembra">Hembra</option>
                </select>
                <input id="animalEdad" type="number" placeholder="Edad">
                
                <input id="animalPeso" type="number" step="0.01" placeholder="Peso en kg" oninput="calcularDosis()">
                <input id="animalAlimento" type="text" placeholder="Alimento diario">
                
                <select id="animalMedicamento" onchange="calcularDosis()" style="width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;">
                    <option value="" data-dosis="0">Seleccione un Medicamento</option>
                    <?php foreach ($medicamentos as$med): ?>
                        <option value="<?php echo $med['MedicamentosId']; ?>" data-dosis="<?php echo $med['DosisBase']; ?>" data-nombre="<?php echo htmlspecialchars($med['Nombre']); ?>">
                            <?php echo htmlspecialchars($med['Nombre']); ?> (Base: <?php echo$med['DosisBase']; ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
                
                <input id="animalDosis" type="text" placeholder="Cantidad a suministrar (Automático)" readonly style="background-color: #e9ecef;">
                
                <label for="animalFechaRevision" style="font-size: 13px; color: #555;">Fecha de ingreso/revisión del medicamento:</label>
                <input id="animalFechaRevision" type="date" required min="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" style="width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;">
                <small id="mensajeFecha" class="validacion-mensaje" aria-live="polite"></small>
                <label style="font-size: 13px; color: #555;">Próxima Dosis:</label>
                <input id="animalProximaDosis" type="date" min="<?php echo date('Y-m-d'); ?>" style="width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;">

                <input id="animalDiagnostico" type="text" placeholder="Diagnóstico">
                <textarea id="animalObservaciones" placeholder="Observaciones" style="width: 100%; padding: 8px; margin-bottom: 10px; border-radius: 4px; border: 1px solid #ccc;"></textarea>
                
                <div id="validacionFormulario" class="validacion-formulario" aria-live="polite"></div>
                <button id="btnGuardar" class="btn-guardar" style="width: 100%;" onclick="guardarOModificarAnimal()">Guardar Animal</button>
                <button id="btnCancelar" class="btn-accion btn-cancelar" onclick="limpiarFormulario()">Cancelar Edición</button>
            </div>

            <!-- LISTA DE ANIMALES -->
            <div class="panel-info" style="flex: 1; background: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
                <h2 style="color: #006400;">Mis Animales Guardados</h2>
                <div id="detalleAnimal">
                    <?php if (empty($misAnimales)): ?>
                        <p style="color: #888;">No tienes animales registrados aún.</p>
                    <?php else: ?>
                        <?php foreach ($misAnimales as$an): ?>
                            <div style="border-bottom: 1px solid #eee; padding: 12px 0;">
                                <strong>ID: <?php echo $an['AnimalId']; ?> - <?php echo htmlspecialchars($an['Nombre']); ?></strong><br>
                                <!-- AQUI SE CORRIGIÓ EL \vert{} POR UN | -->
                                <span>Tipo: <?php echo htmlspecialchars($an['TipoNombre'] ?? 'N/A'); ?> - Raza: <?php echo htmlspecialchars($an['RazaNombre'] ?? 'N/A'); ?></span><br>
                                <span>Peso: <?php echo htmlspecialchars($an['Peso']); ?> kg</span><br>
                                <span style="color: #007bff; font-weight: bold; font-size: 13px;">
                                    Próxima Dosis: <?php echo $an['SiguienteDosis'] ?$an['SiguienteDosis'] : 'Sin dosis pendiente'; ?>
                                </span><br>
                                <button class="btn-accion btn-editar" onclick="cargarParaEditar(<?php echo $an['AnimalId']; ?>)">✏️ Editar</button>
                                <!-- NUEVO BOTÓN PARA DESCARGAR PDF -->
                                <button class="btn-accion btn-pdf" onclick="descargarHistorial(<?php echo $an['AnimalId']; ?>)">📄 PDF</button>
                                <button class="btn-accion btn-eliminar" onclick="eliminarAnimal(<?php echo $an['AnimalId']; ?>)">🗑️ Eliminar</button>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function calcularDosis() {
            const peso = parseFloat(document.getElementById('animalPeso').value) || 0;
            const selectMed = document.getElementById('animalMedicamento');
            const dosisBase = parseFloat(selectMed.options[selectMed.selectedIndex].getAttribute('data-dosis')) || 0;
            
            if (peso > 0 && dosisBase > 0) {
                const total = peso * dosisBase;
                document.getElementById('animalDosis').value = total.toFixed(2);
            } else {
                document.getElementById('animalDosis').value = "";
            }
        }

        function cargarParaEditar(id) {
            fetch(`php/obtener_animal.php?id=${id}`)
            .then(res => res.json())
            .then(res => {
                if (res.status === 'error') {
                    alert(res.message);
                    return;
                }
                const animal = res.data;

                document.getElementById('animalId').value = animal.AnimalId || animal.id_animal || id;
                document.getElementById('animalNombre').value = animal.nombre || '';
                document.getElementById('animalTipo').value = animal.tipo || '';
                document.getElementById('animalRaza').value = animal.raza || '';
                document.getElementById('animalSexo').value = animal.sexo || '';
                document.getElementById('animalEdad').value = animal.edad || '';
                document.getElementById('animalPeso').value = animal.peso || '';
                document.getElementById('animalAlimento').value = animal.alimento_diario || '';
                
                document.getElementById('animalMedicamento').value = animal.MedicamentoId || '';
                calcularDosis();

                document.getElementById('animalProximaDosis').value = animal.proxima_dosis || '';
                document.getElementById('animalDiagnostico').value = animal.diagnostico || '';
                document.getElementById('animalObservaciones').value = animal.observaciones || '';

                document.getElementById('tituloFormulario').textContent = 'Modificar Información del Animal';
                document.getElementById('btnGuardar').textContent = 'Guardar Cambios';
                document.getElementById('btnCancelar').style.display = 'block';

                window.scrollTo({ top: 0, behavior: 'smooth' });
            })
            .catch(err => {
                console.error(err);
                alert('Error al obtener la información del animal.');
            });
        }

        function validarCampo(id, correcto, mensaje) {
            const campo = document.getElementById(id);
            campo.classList.toggle('campo-valido', !!correcto);
            campo.classList.toggle('campo-invalido', !correcto);
            return !!correcto;
        }

        function validarFormulario() {
            const tipo = document.getElementById('animalTipo').value;
            const nombre = document.getElementById('animalNombre').value.trim();
            const peso = parseFloat(document.getElementById('animalPeso').value);
            const fecha = document.getElementById('animalFechaRevision').value;
            const hoy = new Date(); hoy.setHours(0,0,0,0);
            const fechaElegida = fecha ? new Date(fecha + 'T00:00:00') : null;
            const checks = [
                validarCampo('animalNombre', nombre.length > 0),
                validarCampo('animalTipo', tipo !== ''),
                validarCampo('animalPeso', Number.isFinite(peso) && peso > 0),
                validarCampo('animalFechaRevision', !!fechaElegida && fechaElegida >= hoy)
            ];
            const panel = document.getElementById('validacionFormulario');
            if (checks.every(Boolean)) {
                panel.innerHTML = '<span class="check-valido">✓ Datos validados correctamente.</span>';
                document.getElementById('mensajeFecha').textContent = '✓ Fecha válida';
                document.getElementById('mensajeFecha').className = 'validacion-mensaje check-valido';
                return true;
            }
            panel.innerHTML = '<span style="color:#dc3545">Revisa los campos marcados en rojo. El nombre, tipo, peso y fecha de revisión son obligatorios.</span>';
            document.getElementById('mensajeFecha').textContent = 'La fecha no puede ser anterior a hoy.';
            document.getElementById('mensajeFecha').className = 'validacion-mensaje';
            return false;
        }

        document.addEventListener('DOMContentLoaded', () => {
            const fecha = document.getElementById('animalFechaRevision');
            fecha.min = new Date().toISOString().slice(0,10);
            fecha.addEventListener('change', validarFormulario);
            ['animalNombre','animalTipo','animalPeso'].forEach(id => document.getElementById(id).addEventListener('change', validarFormulario));
        });

        function guardarOModificarAnimal() {
            if (!validarFormulario()) return;
            const id = document.getElementById('animalId').value;
            const url = id ? 'php/modificar_animal.php' : 'php/guardar_animal.php';

            const selectMed = document.getElementById('animalMedicamento');
            const nombreMed = selectMed.selectedIndex > 0 ? selectMed.options[selectMed.selectedIndex].getAttribute('data-nombre') : '';

            const payload = {
                animal_id: id,
                nombre: document.getElementById('animalNombre').value,
                tipo: document.getElementById('animalTipo').value,
                raza: document.getElementById('animalRaza').value,
                sexo: document.getElementById('animalSexo').value,
                edad: document.getElementById('animalEdad').value,
                peso: document.getElementById('animalPeso').value,
                alimento_diario: document.getElementById('animalAlimento').value,
                medicamento_id: selectMed.value,
                medicamento_nombre: nombreMed,
                dosis: document.getElementById('animalDosis').value,
                proxima_dosis: document.getElementById('animalProximaDosis').value,
                fecha_revision: document.getElementById('animalFechaRevision').value,
                diagnostico: document.getElementById('animalDiagnostico').value,
                observaciones: document.getElementById('animalObservaciones').value
            };

            fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            })
            .then(res => res.text())
            .then(data => {
                const resTrim = data.trim();
                if (resTrim === 'OK' || resTrim.includes('correctamente') || resTrim.includes('éxito')) {
                    alert(id ? 'Información actualizada correctamente.' : 'Animal registrado con éxito.');
                    location.reload();
                } else {
                    alert(data);
                }
            })
            .catch(() => alert('Error al procesar la solicitud.'));
        }

        function eliminarAnimal(id) {
            if (!confirm('¿Está seguro de eliminar este registro?')) return;

            fetch('php/eliminar_animal.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ animal_id: id })
            })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'success') {
                    alert('Registro eliminado correctamente.');
                    location.reload();
                } else {
                    alert(data.message);
                }
            })
            .catch(() => alert('Error al eliminar el animal.'));
        }

        // NUEVA FUNCIÓN PARA DESCARGAR EL PDF
        function descargarHistorial(id) {
            window.open('php/generar_pdf_historial.php?id=' + id, '_blank');
        }

        function limpiarFormulario() {
            document.getElementById('animalId').value = '';
            document.querySelectorAll('.panel-registro input, .panel-registro textarea').forEach(el => el.value = '');
            document.getElementById('animalSexo').value = '';
            document.getElementById('animalMedicamento').value = '';
            document.getElementById('animalFechaRevision').value = new Date().toISOString().slice(0,10);
            document.getElementById('validacionFormulario').innerHTML = '';
            document.querySelectorAll('.campo-valido, .campo-invalido').forEach(el => el.classList.remove('campo-valido','campo-invalido'));
            document.getElementById('tituloFormulario').textContent = 'Registrar Nuevo Animal';
            document.getElementById('btnGuardar').textContent = 'Guardar Animal';
            document.getElementById('btnCancelar').style.display = 'none';
        }
    </script>
</body>
</html>