<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registro</title>
    <link rel="stylesheet" href="css/RegistroUser.css">
</head>
<body class="registro-body">
    <div class="registro-contenedor">
        <h2>Registrarse</h2>
        <input id="nombre" type="text" placeholder="Nombre">
        <input id="correo" type="email" placeholder="Correo">
        <input id="contraseña" type="password" placeholder="Contraseña">
        
        <!-- Nuevos campos integrados -->
        <select id="generoId">
            <option value="" disabled selected>Seleccione Género</option>
            <option value="1">Masculino</option>
            <option value="2">Femenino</option>
            <option value="3">Otro</option>
        </select>
        
        <select id="tipoDocumento">
            <option value="" disabled selected>Tipo de Documento</option>
            <option value="1">Cédula de Ciudadanía</option>
            <option value="2">Tarjeta de Identidad</option>
            <option value="3">Cédula de Extranjería</option>
        </select>
        
        <input id="noDocumento" type="number" placeholder="Número de Documento (Ej. 1012345678)">
        <input id="fechaNacimiento" type="date">
        <input id="celular" type="text" placeholder="Teléfono / Celular">
        <input id="direccion" type="text" placeholder="Dirección (Ej. Calle 123 #45-67)">

        <button onclick="registrar()">Registrarse</button>
        <br><br>
        <a href="login.php">Ya tengo cuenta</a>
    </div>
    <a href="administrador.php" class="admin-link">Administrador</a>
    <script src="script.js"></script>
</body>
</html>