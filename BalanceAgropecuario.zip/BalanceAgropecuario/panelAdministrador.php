<?php
session_start();
require_once "php/conexion.php";

// Alta de medicamentos desde el panel del administrador.
$mensajeMedicamento = "";
$tipoMensajeMedicamento = "";
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["accion"] ?? "") === "agregar_medicamento") {
    if (empty($_SESSION["id_administrador"])) {
        http_response_code(403);
        exit("Acceso no autorizado.");
    }

    $nombreMedicamento = trim($_POST["nombre_medicamento"] ?? "");
    $descripcionMedicamento = trim($_POST["descripcion_medicamento"] ?? "");
    $dosisBase = filter_var($_POST["dosis_base"] ?? "", FILTER_VALIDATE_INT);

    if ($nombreMedicamento === "" || mb_strlen($nombreMedicamento) > 100 || $dosisBase === false || $dosisBase < 0) {
        $mensajeMedicamento = "Escribe un nombre (máximo 100 caracteres) y una dosis base válida (número igual o mayor que cero).";
        $tipoMensajeMedicamento = "error";
    } else {
        try {
            $insertarMedicamento = $conexion->prepare("INSERT INTO Medicamento (Nombre, Descripcion, DosisBase) VALUES (?, ?, ?)");
            $insertarMedicamento->execute([$nombreMedicamento, $descripcionMedicamento !== "" ? $descripcionMedicamento : null, $dosisBase]);
            header("Location: panelAdministrador.php?medicamento=agregado");
            exit;
        } catch (PDOException $e) {
            if ($e->getCode() === "23000") {
                $mensajeMedicamento = "Ya existe un medicamento con ese nombre. Escribe un nombre diferente.";
            } else {
                $mensajeMedicamento = "No se pudo guardar el medicamento. Verifica la conexión con la base de datos.";
            }
            $tipoMensajeMedicamento = "error";
        }
    }
}
if (isset($_GET["medicamento"]) && $_GET["medicamento"] === "agregado") {
    $mensajeMedicamento = "Medicamento agregado correctamente. Ya está disponible para los usuarios al registrar un animal.";
    $tipoMensajeMedicamento = "exito";
}

// Lógica directa para suspender/activar usuario sin errores de ruta o fetch
if (isset($_GET['accion']) && $_GET['accion'] === 'suspender' && isset($_GET['id'])) {
    $idUsuario = $_GET['id'];

    $stmt = $conexion->prepare("SELECT estado FROM Usuario WHERE UsuarioId = ?");
    $stmt->execute([$idUsuario]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($u) {
        $estadoActual = !empty($u['estado']) ? $u['estado'] : 'Activo';
        $nuevoEstado = ($estadoActual === 'Suspendido') ? 'Activo' : 'Suspendido';

        $update = $conexion->prepare("UPDATE Usuario SET estado = ? WHERE UsuarioId = ?");
        $update->execute([$nuevoEstado, $idUsuario]);
    }

    header("Location: panelAdministrador.php");
    exit();
}

// 1. Conteos generales
$totalUsuarios = $conexion->query("SELECT COUNT(*) FROM Usuario")->fetchColumn();
$totalAnimales = $conexion->query("SELECT COUNT(*) FROM Animal")->fetchColumn();

// 2. Consulta de usuarios
$sqlUsuarios = "SELECT u.UsuarioId, u.Nombre, u.Apellido, u.Email, u.estado, 
               (SELECT COUNT(*) FROM Animal a WHERE a.UsuarioId = u.UsuarioId) AS TotalAnimales 
                FROM Usuario u ORDER BY u.UsuarioId DESC";
$listaUsuarios = $conexion->query($sqlUsuarios)->fetchAll(PDO::FETCH_ASSOC);

// 3. Consulta de animales
$sqlAnimales = "SELECT a.AnimalId, a.Nombre AS NombreAnimal, a.Sexo, a.Edad, a.Peso, 
                       CONCAT(u.Nombre, ' ', IFNULL(u.Apellido, '')) AS NombreDueno,
                       u.Email AS CorreoDueno,
                       ta.Nombre AS Tipo, ta.Raza AS Raza,
                       (SELECT MIN(v.ProximaDosis) FROM Vacunacion v WHERE v.AnimalId = a.AnimalId AND v.ProximaDosis >= CURDATE()) AS SiguienteDosis
                FROM Animal a
                INNER JOIN Usuario u ON a.UsuarioId = u.UsuarioId
                LEFT JOIN TipoAnimal ta ON a.TipoAnimalId = ta.TipoAnimalId
                ORDER BY a.AnimalId DESC";
$listaAnimales = $conexion->query($sqlAnimales)->fetchAll(PDO::FETCH_ASSOC);

// 4. Historial de medicamentos para consulta del administrador
$sqlMedicamentos = "SELECT v.VacunacionId, v.NombreVacuna AS Medicamento, v.FechaAplicacion,
                           v.ProximaDosis, a.Nombre AS NombreAnimal, ta.Nombre AS TipoAnimal,
                           CONCAT(u.Nombre, ' ', IFNULL(u.Apellido, '')) AS Responsable,
                           (SELECT p.DosisCalculada FROM Produccion p WHERE p.AnimalId = a.AnimalId
                            AND p.MedicamentoId = v.MedicamentoId ORDER BY p.Fecha DESC, p.ProduccionId DESC LIMIT 1) AS Dosis
                    FROM Vacunacion v
                    INNER JOIN Animal a ON v.AnimalId = a.AnimalId
                    INNER JOIN Usuario u ON a.UsuarioId = u.UsuarioId
                    LEFT JOIN TipoAnimal ta ON a.TipoAnimalId = ta.TipoAnimalId
                    ORDER BY v.FechaAplicacion DESC, v.VacunacionId DESC";
$listaMedicamentos = $conexion->query($sqlMedicamentos)->fetchAll(PDO::FETCH_ASSOC);

// Catálogo maestro que alimenta el selector de medicamentos de los usuarios.
$catalogoMedicamentos = $conexion->query("SELECT MedicamentosId, Nombre, Descripcion, DosisBase FROM Medicamento ORDER BY Nombre ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel de Administración - Balance Agropecuario</title>
    <style>
        * { box-sizing: border-box; font-family: Arial, sans-serif; margin: 0; padding: 0; }
        body { display: flex; height: 100vh; background-color: #f4f6f9; }
        .sidebar { width: 240px; background-color: #0b6623; color: white; padding: 20px 10px; flex-shrink: 0; }
        .sidebar h2 { margin-bottom: 25px; padding-left: 10px; font-size: 20px; }
        .sidebar ul { list-style: none; }
        .sidebar ul li button {
            width: 100%; text-align: left; padding: 12px 15px; margin-bottom: 8px;
            background: rgba(255, 255, 255, 0.1); color: white; border: none;
            border-radius: 5px; cursor: pointer; font-size: 15px; font-weight: bold;
        }
        .sidebar ul li button:hover, .sidebar ul li button.active { background-color: #1b8a3e; }

        .main-content { flex: 1; padding: 30px; overflow-y: auto; }
        .tab-panel { display: none; }
        .tab-panel.active { display: block; }

        .cards-container { display: flex; gap: 20px; margin-bottom: 25px; }
        .card { background: white; padding: 20px; border-radius: 8px; flex: 1; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .card h3 { color: #0b6623; font-size: 16px; margin-bottom: 10px; }
        .card p { font-size: 32px; font-weight: bold; color: #28a745; }

        table { width: 100%; border-collapse: collapse; background: white; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 4px rgba(0,0,0,0.1); margin-top: 15px; }
        th, td { padding: 12px 15px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background-color: #0b6623; color: white; }
        tr:hover { background-color: #f1f1f1; }

        .estado-activo { color: #28a745; font-weight: bold; }
        .estado-suspendido { color: #dc3545; font-weight: bold; }
        .btn-accion { padding: 5px 10px; border-radius: 3px; color: white; text-decoration: none; font-size: 14px; font-weight: bold; display: inline-block; }

        /* Presentación ejecutiva del reporte descargable */
        .report-header { background: linear-gradient(120deg, #084c22, #168344); color: #fff; padding: 28px 30px; border-radius: 12px; margin-bottom: 22px; }
        .report-kicker { text-transform: uppercase; letter-spacing: 2px; font-size: 11px; font-weight: bold; opacity: .85; margin-bottom: 9px; }
        .report-header h1 { font-size: 28px; margin-bottom: 8px; }
        .report-header p { font-size: 13px; line-height: 1.6; color: #effaf1; }
        .report-meta { display: flex; flex-wrap: wrap; gap: 10px 26px; margin-top: 18px; font-size: 12px; }
        .report-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 14px; margin-bottom: 24px; }
        .report-metric { background: #fff; border: 1px solid #e1e8e3; border-top: 4px solid #168344; border-radius: 9px; padding: 17px; box-shadow: 0 2px 7px rgba(18, 55, 31, .05); }
        .report-metric .metric-label { color: #617066; font-size: 11px; text-transform: uppercase; letter-spacing: .7px; font-weight: bold; }
        .report-metric .metric-value { color: #143d24; font-size: 30px; font-weight: 800; margin-top: 9px; }
        .report-metric .metric-note { color: #718078; font-size: 11px; margin-top: 4px; }
        .report-section { background: #fff; border: 1px solid #e1e8e3; border-radius: 9px; padding: 20px; margin-bottom: 18px; }
        .report-section h2 { color: #174b2b; font-size: 16px; padding-bottom: 11px; border-bottom: 1px solid #e7eee9; margin-bottom: 13px; }
        .report-summary-list { display: grid; grid-template-columns: 1fr 1fr; gap: 12px 30px; }
        .report-summary-row { display: flex; justify-content: space-between; gap: 12px; padding: 9px 0; border-bottom: 1px solid #eef2ef; font-size: 13px; }
        .report-summary-row span { color: #657268; }
        .report-summary-row strong { color: #1d3c28; text-align: right; }
        .report-footer { border-top: 1px solid #dce6de; padding-top: 13px; margin-top: 24px; color: #66746a; font-size: 10px; display: flex; justify-content: space-between; gap: 15px; }
        .report-actions { display: flex; gap: 10px; margin: 0 0 20px; }
        .report-download { border: 0; border-radius: 6px; padding: 12px 18px; font-weight: bold; cursor: pointer; background: #126b35; color: white; }
        .report-download:hover { background: #0a5127; }
        @media (max-width: 900px) { .report-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
        @media print {
            @page { size: A4; margin: 14mm; }
            body { display: block !important; height: auto !important; background: #fff !important; color: #17251b; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .sidebar, .report-actions { display: none !important; }
            .main-content { padding: 0 !important; overflow: visible !important; }
            .tab-panel { display: none !important; }
            #secEstadisticas, #secEstadisticas.active { display: block !important; }
            .report-header { border-radius: 0; padding: 22px 24px; break-inside: avoid; }
            .report-grid { grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 8px; }
            .report-metric { padding: 12px; box-shadow: none; break-inside: avoid; }
            .report-metric .metric-value { font-size: 24px; }
            .report-section { box-shadow: none; break-inside: avoid; padding: 15px; }
            .report-footer { margin-top: 18px; }
        }
    </style>
</head>
<body>

    <div class="sidebar">
        <h2>Administrador</h2>
        <ul>
            <li><button class="active" onclick="mostrarTab('secInicio', this)">🏠 Inicio</button></li>
            <li><button onclick="mostrarTab('secUsuarios', this)">👤 Usuarios</button></li>
            <li><button onclick="mostrarTab('secAnimales', this)">🐕 Animales</button></li>
            <li><button onclick="mostrarTab('secMedicamentos', this)">💊 Medicamentos</button></li>
            <li><button onclick="mostrarTab('secEstadisticas', this)">📊 Estadísticas</button></li>
            <li><button onclick="location.href='php/logout_admin.php'">🚪 Cerrar sesión</button></li>
        </ul>
    </div>

    <div class="main-content">

        <!-- INICIO -->
        <div id="secInicio" class="tab-panel active">
            <h1 style="color: #0b6623; margin-bottom: 20px;">Panel del Administrador</h1>
            <div class="cards-container">
                <div class="card">
                    <h3>Usuarios registrados</h3>
                    <p><?php echo $totalUsuarios; ?></p>
                </div>
                <div class="card">
                    <h3>Animales registrados</h3>
                    <p><?php echo $totalAnimales; ?></p>
                </div>
            </div>

            <h2>Últimos Usuarios</h2>
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Correo</th>
                        <th>Total Animales</th>
                        <th>Estado</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($listaUsuarios as $u): ?>
                    <?php 
                        $esSuspendido = ($u['estado'] === 'Suspendido');
                        $btnTexto = $esSuspendido ? "Reactivar" : "Suspender";
                        $btnColor = $esSuspendido ? "#28a745" : "#e0a800";
                    ?>
                    <tr>
                        <td><?php echo htmlspecialchars($u['Nombre'] . ' ' . $u['Apellido']); ?></td>
                        <td><?php echo htmlspecialchars($u['Email']); ?></td>
                        <td><?php echo $u['TotalAnimales']; ?></td>
                        <td class="<?php echo $esSuspendido ? 'estado-suspendido' : 'estado-activo'; ?>">
                            <?php echo htmlspecialchars($u['estado'] ?? 'Activo'); ?>
                        </td>
                        <td>
                            <a href="panelAdministrador.php?accion=suspender&id=<?php echo $u['UsuarioId']; ?>" 
                               style="background-color: <?php echo $btnColor; ?>;" class="btn-accion"
                               onclick="return confirm('¿Está seguro de cambiar el estado de este usuario?');">
                                <?php echo $btnTexto; ?>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- USUARIOS -->
        <div id="secUsuarios" class="tab-panel">
            <h1 style="color: #0b6623; margin-bottom: 20px;">Gestión de Usuarios</h1>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre Completo</th>
                        <th>Correo Electrónico</th>
                        <th>Total Animales</th>
                        <th>Estado</th>
                        <th>Acción</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($listaUsuarios as $u): ?>
                    <?php 
                        $esSuspendido = ($u['estado'] === 'Suspendido');
                        $btnTexto = $esSuspendido ? "Reactivar" : "Suspender";
                        $btnColor = $esSuspendido ? "#28a745" : "#e0a800";
                    ?>
                    <tr>
                        <td><?php echo $u['UsuarioId']; ?></td>
                        <td><?php echo htmlspecialchars($u['Nombre'] . ' ' . $u['Apellido']); ?></td>
                        <td><?php echo htmlspecialchars($u['Email']); ?></td>
                        <td><?php echo $u['TotalAnimales']; ?></td>
                        <td class="<?php echo $esSuspendido ? 'estado-suspendido' : 'estado-activo'; ?>">
                            <?php echo htmlspecialchars($u['estado'] ?? 'Activo'); ?>
                        </td>
                        <td>
                            <a href="panelAdministrador.php?accion=suspender&id=<?php echo $u['UsuarioId']; ?>" 
                               style="background-color: <?php echo $btnColor; ?>;" class="btn-accion"
                               onclick="return confirm('¿Está seguro de cambiar el estado de este usuario?');">
                                <?php echo $btnTexto; ?>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- ANIMALES -->
        <div id="secAnimales" class="tab-panel">
            <h1 style="color: #0b6623; margin-bottom: 20px;">Registro General de Animales</h1>
            <table>
                <thead>
                    <tr>
                        <th>ID Animal</th>
                        <th>Nombre</th>
                        <th>Dueño</th>
                        <th>Tipo</th>
                        <th>Raza</th>
                        <th>Peso (kg)</th>
                        <th>Próxima Dosis</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($listaAnimales as $an): ?>
                    <tr>
                        <td><?php echo $an['AnimalId']; ?></td>
                        <td><?php echo htmlspecialchars($an['NombreAnimal']); ?></td>
                        <td><?php echo htmlspecialchars($an['NombreDueno']); ?> (<?php echo htmlspecialchars($an['CorreoDueno']); ?>)</td>
                        <td><?php echo htmlspecialchars($an['Tipo'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($an['Raza'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($an['Peso']); ?></td>
                        <td><?php echo $an['SiguienteDosis'] ? $an['SiguienteDosis'] : 'Sin dosis pendiente'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- MEDICAMENTOS -->
        <div id="secMedicamentos" class="tab-panel">
            <h1 style="color: #0b6623; margin-bottom: 20px;">Formulario e historial de medicamentos</h1>
            <p style="margin-bottom: 15px;">Desde aquí puedes agregar medicamentos al catálogo. Al guardarlos en la base de datos, aparecerán automáticamente en el selector que utilizan los usuarios al registrar animales.</p>

            <?php if ($mensajeMedicamento !== ""): ?>
                <div role="status" style="padding:12px 15px; margin:12px 0; border-radius:6px; background:<?php echo $tipoMensajeMedicamento === 'exito' ? '#d4edda' : '#f8d7da'; ?>; color:<?php echo $tipoMensajeMedicamento === 'exito' ? '#155724' : '#721c24'; ?>;">
                    <?php echo htmlspecialchars($mensajeMedicamento, ENT_QUOTES, 'UTF-8'); ?>
                </div>
            <?php endif; ?>

            <div style="background:#fff; padding:20px; border-radius:8px; margin:15px 0 25px; box-shadow:0 2px 4px rgba(0,0,0,.1); max-width:850px;">
                <h2 style="color:#0b6623; margin-bottom:15px;">Agregar nuevo medicamento</h2>
                <form method="POST" action="panelAdministrador.php" style="display:grid; gap:12px;">
                    <input type="hidden" name="accion" value="agregar_medicamento">
                    <label>Nombre del medicamento
                        <input type="text" name="nombre_medicamento" maxlength="100" required style="display:block; width:100%; padding:10px; margin-top:5px; border:1px solid #ccc; border-radius:5px;">
                    </label>
                    <label>Descripción (opcional)
                        <textarea name="descripcion_medicamento" rows="3" style="display:block; width:100%; padding:10px; margin-top:5px; border:1px solid #ccc; border-radius:5px;"></textarea>
                    </label>
                    <label>Dosis base (número)
                        <input type="number" name="dosis_base" min="0" step="1" required style="display:block; width:100%; padding:10px; margin-top:5px; border:1px solid #ccc; border-radius:5px;">
                    </label>
                    <button type="submit" style="justify-self:start; padding:11px 18px; background:#0b6623; color:#fff; border:0; border-radius:5px; cursor:pointer; font-weight:bold;">Guardar medicamento</button>
                </form>
            </div>

            <h2 style="color:#0b6623; margin-bottom:10px;">Catálogo de medicamentos disponibles para usuarios</h2>
            <div style="overflow-x:auto; margin-bottom:30px;">
                <table>
                    <thead><tr><th>Nombre</th><th>Descripción</th><th>Dosis base</th></tr></thead>
                    <tbody>
                    <?php if (empty($catalogoMedicamentos)): ?>
                        <tr><td colspan="3">No hay medicamentos en el catálogo.</td></tr>
                    <?php else: foreach ($catalogoMedicamentos as $itemMedicamento): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($itemMedicamento['Nombre'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($itemMedicamento['Descripcion'] ?? '—', ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars((string)($itemMedicamento['DosisBase'] ?? '—'), ENT_QUOTES, 'UTF-8'); ?></td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>

            <h2 style="color:#0b6623; margin-bottom:10px;">Historial de medicamentos registrados en animales</h2>
            <div style="overflow-x:auto;">
            <table>
                <thead><tr><th>Animal</th><th>Tipo</th><th>Medicamento</th><th>Dosis</th><th>Fecha de ingreso/revisión</th><th>Próxima dosis</th><th>Responsable</th></tr></thead>
                <tbody>
                <?php if (empty($listaMedicamentos)): ?>
                    <tr><td colspan="7">Todavía no hay registros de medicamentos.</td></tr>
                <?php else: foreach ($listaMedicamentos as $med): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($med['NombreAnimal'] ?? 'Sin nombre'); ?></td>
                        <td><?php echo htmlspecialchars($med['TipoAnimal'] ?? 'N/D'); ?></td>
                        <td><?php echo htmlspecialchars($med['Medicamento'] ?? 'N/D'); ?></td>
                        <td><?php echo $med['Dosis'] !== null ? htmlspecialchars((string)$med['Dosis']) : 'N/D'; ?></td>
                        <td><?php echo htmlspecialchars($med['FechaAplicacion'] ?? 'N/D'); ?></td>
                        <td><?php echo htmlspecialchars($med['ProximaDosis'] ?? 'No definida'); ?></td>
                        <td><?php echo htmlspecialchars(trim($med['Responsable'] ?? '') ?: 'N/D'); ?></td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
            </div>
        </div>

        <!-- ESTADÍSTICAS / REPORTE EJECUTIVO -->
        <div id="secEstadisticas" class="tab-panel">
            <div class="report-actions">
                <button class="report-download" type="button" onclick="descargarReporteEstadistico()">📄 Descargar reporte en PDF</button>
            </div>

            <div id="contenidoReporteEstadistico">
                <header class="report-header">
                    <div class="report-kicker">Balance Agropecuario · Informe de gestión</div>
                    <h1>Reporte de estadísticas del sistema</h1>
                    <p>Resumen ejecutivo de usuarios, inventario animal y gestión de medicamentos registrados en la plataforma.</p>
                    <div class="report-meta">
                        <span><strong>Generado:</strong> <?php echo date("d/m/Y H:i"); ?></span>
                        <span><strong>Periodo:</strong> Acumulado al momento de la consulta</span>
                        <span><strong>Estado:</strong> Informe administrativo</span>
                    </div>
                </header>

                <div class="report-grid">
                    <div class="report-metric">
                        <div class="metric-label">Usuarios registrados</div>
                        <div class="metric-value"><?php echo number_format((int)$totalUsuarios, 0, ',', '.'); ?></div>
                        <div class="metric-note">Cuentas en la plataforma</div>
                    </div>
                    <div class="report-metric">
                        <div class="metric-label">Animales registrados</div>
                        <div class="metric-value"><?php echo number_format((int)$totalAnimales, 0, ',', '.'); ?></div>
                        <div class="metric-note">Inventario animal total</div>
                    </div>
                    <div class="report-metric">
                        <div class="metric-label">Medicamentos disponibles</div>
                        <div class="metric-value"><?php echo number_format(count($catalogoMedicamentos), 0, ',', '.'); ?></div>
                        <div class="metric-note">Elementos del catálogo</div>
                    </div>
                    <div class="report-metric">
                        <div class="metric-label">Registros de aplicación</div>
                        <div class="metric-value"><?php echo number_format(count($listaMedicamentos), 0, ',', '.'); ?></div>
                        <div class="metric-note">Historial consultado</div>
                    </div>
                </div>

                <section class="report-section">
                    <h2>Indicadores generales</h2>
                    <div class="report-summary-list">
                        <div class="report-summary-row"><span>Promedio de animales por usuario</span><strong><?php echo $totalUsuarios > 0 ? number_format($totalAnimales / $totalUsuarios, 2, ',', '.') : '0,00'; ?></strong></div>
                        <div class="report-summary-row"><span>Medicamentos en el catálogo</span><strong><?php echo number_format(count($catalogoMedicamentos), 0, ',', '.'); ?></strong></div>
                        <div class="report-summary-row"><span>Registros de medicamentos / vacunación</span><strong><?php echo number_format(count($listaMedicamentos), 0, ',', '.'); ?></strong></div>
                        <div class="report-summary-row"><span>Fuente de información</span><strong>Base de datos del sistema</strong></div>
                    </div>
                </section>

                <section class="report-section">
                    <h2>Alcance y notas del informe</h2>
                    <p style="font-size:13px;line-height:1.7;color:#526257;">Este reporte presenta un corte de los datos disponibles al momento de su generación. Las cifras corresponden a registros almacenados en Balance Agropecuario; no representan proyecciones ni datos estimados. Para decisiones operativas, se recomienda verificar que los registros de animales y aplicaciones de medicamentos se encuentren actualizados.</p>
                </section>

                <footer class="report-footer">
                    <span>Balance Agropecuario · Reporte administrativo</span>
                    <span>Documento generado desde el panel del administrador</span>
                </footer>
            </div>
        </div>

    </div>

    <script>
        function descargarReporteEstadistico() {
            // Asegura que al imprimir se incluya únicamente el reporte estadístico.
            document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
            document.getElementById('secEstadisticas').classList.add('active');
            window.print();
        }

        function mostrarTab(tabId, btn) {
            document.querySelectorAll('.tab-panel').forEach(panel => panel.classList.remove('active'));
            document.querySelectorAll('.sidebar button').forEach(b => b.classList.remove('active'));
            document.getElementById(tabId).classList.add('active');
            btn.classList.add('active');
        }
    </script>
</body>
</html>